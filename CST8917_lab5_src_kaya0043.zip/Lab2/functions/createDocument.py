import azure.functions as func
import pymongo
import os
import json
from typing import Any

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Get environment variables from Azure Functions configuration
        cosmos_db_connection = "mongodb://cst8922cosmosdb:Nsh8ylRRT7oB5zPVOO48F5FNu7DQncBCFUnYy1ae0Qzxvbc1NzZS1aOdXC1jq6P0pQuTNuUsh0Y3ACDbe9yYNQ==@cst8922cosmosdb.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cst8922cosmosdb@"
        db_name = "cst8917_lab2_database"
        collection_name = "lab2_collection"

        if not all([cosmos_db_connection, db_name, collection_name]):
            raise ValueError("Missing Cosmos DB configuration in application settings")

        # Initialize MongoDB client inside the function for better cold start performance
        mongo_client = pymongo.MongoClient(cosmos_db_connection)
        collection = mongo_client[db_name][collection_name]

        # Process request
        req_body = req.get_json()
        if not req_body:
            return func.HttpResponse(
                "Please pass a document in the request body",
                status_code=400
            )

        # Insert document
        result = collection.insert_one(req_body)
        inserted_id = str(result.inserted_id)

        return func.HttpResponse(
            json.dumps({
                "id": inserted_id,
                "message": "Document created successfully",
                "database": db_name,
                "collection": collection_name
            }),
            status_code=201,
            mimetype="application/json",
            headers={"Content-Type": "application/json"}
        )

    except pymongo.errors.PyMongoError as mongo_error:
        return func.HttpResponse(
            json.dumps({"error": f"MongoDB error: {str(mongo_error)}"}),
            status_code=500,
            mimetype="application/json"
        )
    except Exception as generic_error:
        return func.HttpResponse(
            json.dumps({"error": f"Server error: {str(generic_error)}"}),
            status_code=500,
            mimetype="application/json"
        )